// Reglas del juego. No toca el DOM: se comunica con la interfaz mediante `hooks`.
const esc = s => String(s).replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const r6 = () => 1 + Math.floor(Math.random() * 6);
const shuffle = a => { for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; };

class Player {
  constructor(c) { Object.assign(this, c, { money: 1500, pos: 0, jail: 0, inJail: false, cards: 0, out: false }); }
}

class Game {
  constructor(cfg, hooks) {
    this.h = hooks;
    this.players = cfg.map(c => new Player(c));
    this.sp = SPACES.map((s, i) => ({ ...s, id: i, owner: null, houses: 0, mort: false })); // estado propio, sin mutar SPACES
    this.decks = { chance: shuffle(CHANCE.slice()), chest: shuffle(CHEST.slice()) };
    this.cur = 0; this.over = false;
  }
  p() { return this.players[this.cur]; }
  idx(p) { return this.players.indexOf(p); }
  n(p) { return `<b style="color:${p.color}">${esc(p.name)}</b>`; }
  log(m, c) { this.h.log(m, c); }
  own(i) { return this.sp.filter(s => s.owner === i); }
  grp(s) { return this.sp.filter(x => x.g === s.g); }
  hasSet(i, g) { return this.sp.filter(x => x.g === g).every(x => x.owner === i); }

  rent(s, roll) {
    const mine = this.own(s.owner);
    if (s.type === "railroad") return 25 * 2 ** (mine.filter(x => x.type === "railroad").length - 1);
    if (s.type === "utility") return roll * (mine.filter(x => x.type === "utility").length > 1 ? 10 : 4);
    if (s.houses) return Math.round(s.r * MULT[s.g][s.houses - 1]);
    return this.hasSet(s.owner, s.g) ? s.r * 2 : s.r;
  }

  // --- Construcción e hipotecas (regla de construcción uniforme) ---
  canBuild(s) { return s.type === "property" && s.owner !== null && s.houses < 5 && this.hasSet(s.owner, s.g) && this.grp(s).every(x => !x.mort && x.houses >= s.houses) && this.players[s.owner].money >= G[s.g][1]; }
  build(s) { this.players[s.owner].money -= G[s.g][1]; s.houses++; }
  canSell(s) { return s.houses > 0 && this.grp(s).every(x => x.houses <= s.houses); }
  sell(s) { this.players[s.owner].money += G[s.g][1] / 2; s.houses--; }
  canMort(s) { return s.owner !== null && !s.mort && (s.type !== "property" || this.grp(s).every(x => !x.houses)); }
  mort(s) { this.players[s.owner].money += s.price / 2; s.mort = true; }
  unmortCost(s) { return Math.ceil(s.price * 0.55); }
  canUnmort(s) { return s.mort && this.players[s.owner].money >= this.unmortCost(s); }
  unmort(s) { this.players[s.owner].money -= this.unmortCost(s); s.mort = false; }

  // --- Dinero ---
  async pay(p, amt, to) {
    while (p.money < amt && !p.out) {
      const c = await this.h.ask("Fondos insuficientes", `${this.n(p)} debe ${amt}M y solo tiene ${p.money}M.`, ["Gestionar propiedades", "Declarar bancarrota"]);
      if (c === "Gestionar propiedades") await this.h.manage(this, p); else await this.bankrupt(p, to);
    }
    if (p.out) return false;
    p.money -= amt; this.h.flash(p, -amt);
    if (to) { to.money += amt; this.h.flash(to, amt); }
    this.h.render(); return true;
  }
  gain(p, amt) { p.money += amt; this.h.flash(p, amt); this.h.render(); }

  async bankrupt(p, to) {
    this.log(`${this.n(p)} se declara en bancarrota.`, "neg");
    const i = this.idx(p);
    this.own(i).forEach(s => { s.houses = 0; if (to) s.owner = this.idx(to); else { s.owner = null; s.mort = false; } });
    if (to) { to.money += p.money; to.cards += p.cards; }
    p.money = 0; p.cards = 0; p.out = true;
    const alive = this.players.filter(q => !q.out);
    if (alive.length === 1) { this.over = true; this.h.render(); await this.h.win(alive[0]); }
  }

  // --- Movimiento ---
  async roll() {
    const a = r6(), b = r6(); await this.h.dice(a, b);
    this.log(`${this.n(this.p())} saca ${a} + ${b} = ${a + b}.`); return [a, b];
  }
  async moveBy(p, n) {
    for (let i = 0; i < n; i++) {
      p.pos = (p.pos + 1) % 40;
      if (!p.pos) { this.log(`${this.n(p)} cobra 200M al pasar por la Ronda de Inversión.`, "pos"); this.gain(p, 200); }
      await this.h.step(p);
    }
  }
  async jail(p) {
    p.pos = 10; p.inJail = true; p.jail = 0;
    this.log(`${this.n(p)} va a la Auditoría Fiscal.`, "neg"); await this.h.step(p); this.h.render();
  }

  async turn() {
    const p = this.p();
    if (p.inJail) {
      const o = ["Pagar 50M"]; if (p.cards) o.push("Usar carta"); o.push("Intentar dobles");
      const c = await this.h.ask("Auditoría Fiscal", `${this.n(p)} está en la Auditoría. ¿Cómo quiere salir?`, o);
      if (c === "Pagar 50M") { if (await this.pay(p, 50, null)) { p.inJail = false; this.log(`${this.n(p)} paga 50M y sale.`); } }
      else if (c === "Usar carta") { p.cards--; p.inJail = false; this.log(`${this.n(p)} usa su carta y sale.`); }
      else {
        const [a, b] = await this.roll();
        if (a === b) { p.inJail = false; this.log("¡Dobles! Sale de la Auditoría."); await this.moveBy(p, a + b); await this.land(p, a + b); }
        else if (++p.jail >= 3) { this.log("Tercer intento fallido: paga 50M."); if (await this.pay(p, 50, null)) { p.inJail = false; await this.moveBy(p, a + b); await this.land(p, a + b); } }
        else this.log("No saca dobles.");
        if (!this.over) this.next(); return;
      }
    }
    let again = true, n = 0;
    while (again && !p.out && !this.over && !p.inJail) {
      const [a, b] = await this.roll(); again = a === b;
      if (again && ++n === 3) { this.log("Tres dobles seguidos.", "neg"); await this.jail(p); break; }
      await this.moveBy(p, a + b); await this.land(p, a + b);
      if (again && !p.out && !this.over && !p.inJail) await this.h.ask("¡Dobles!", `${this.n(p)} tira otra vez.`, ["Tirar de nuevo"]); else again = false;
    }
    if (!this.over) this.next();
  }
  next() { do { this.cur = (this.cur + 1) % this.players.length; } while (this.p().out); this.h.render(); }

  // --- Casillas ---
  async land(p, roll) {
    const s = this.sp[p.pos];
    this.log(`${this.n(p)} cae en <b>${s.name}</b>.`);
    if (["property", "railroad", "utility"].includes(s.type)) await this.landOwn(p, s, roll);
    else if (s.type === "tax") { this.log(`${this.n(p)} paga ${s.amount}M por ${s.name}.`, "neg"); await this.pay(p, s.amount, null); }
    else if (s.type === "chance" || s.type === "chest") await this.draw(p, s.type);
    else if (s.id === 30) await this.jail(p);
  }
  async landOwn(p, s, roll) {
    const me = this.idx(p);
    if (s.owner === null) {
      if (p.money < s.price) { this.log(`${this.n(p)} no tiene fondos para ${s.name}.`); return; }
      if (await this.h.buy(s, p)) { p.money -= s.price; s.owner = me; this.log(`${this.n(p)} compra <b>${s.name}</b> por ${s.price}M.`, "buy"); this.h.flash(p, -s.price); this.h.render(); }
      else this.log(`${this.n(p)} no compra ${s.name}.`);
    } else if (s.owner !== me && !s.mort) {
      const o = this.players[s.owner], r = this.rent(s, roll || r6() + r6());
      this.log(`${this.n(p)} paga ${r}M de alquiler a ${this.n(o)}.`, "neg"); await this.pay(p, r, o);
    }
  }
  async draw(p, k) {
    const d = this.decks[k], c = d.shift(); d.push(c);
    await this.h.card(k, c.t); this.log(`${this.n(p)} roba: ${c.t}.`);
    if (c.m > 0) this.gain(p, c.m);
    else if (c.m < 0) await this.pay(p, -c.m, null);
    else if (c.g !== undefined) { await this.moveBy(p, (c.g - p.pos + 40) % 40); await this.land(p, 0); }
    else if (c.b) { p.pos = (p.pos + 40 - c.b) % 40; await this.h.step(p); await this.land(p, 0); }
    else if (c.j) await this.jail(p);
    else if (c.f) p.cards++;
    else if (c.e) for (const q of this.players) { if (q === p || q.out || p.out || this.over) continue; c.e > 0 ? await this.pay(q, c.e, p) : await this.pay(p, -c.e, q); }
  }
}
