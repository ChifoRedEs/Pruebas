// Interfaz: tablero, panel, ventanas y ajustes de apariencia.
const $ = i => document.getElementById(i);
const h = (t, c, x) => { const e = document.createElement(t); if (c) e.className = c; if (x != null) e.textContent = x; return e; };
const sleep = ms => new Promise(r => setTimeout(r, ms));
const COLORS = ["#ff5d5d", "#4da3ff", "#3ddc97", "#ffc83d"], ICONS = ["🦊", "🤖", "🦄", "🐙", "🚀", "👾"];
const DEF = { theme: "silicio", accent: "", zoom: 100, font: "sans", anim: true };
let S = loadSettings(), game = null, tokens = [], cells = [], pcs = [], busy = false;
const wait = ms => S.anim ? sleep(ms) : Promise.resolve();
const dlg = $("dlg");

function loadSettings() { try { return { ...DEF, ...JSON.parse(localStorage.getItem("mt_set") || "{}") }; } catch (e) { return { ...DEF }; } }
function apply() {
  const r = document.documentElement;
  r.dataset.theme = S.theme; r.dataset.font = S.font; r.classList.toggle("noanim", !S.anim);
  r.style.setProperty("--zoom", S.zoom / 100);
  if (S.accent) {
    const n = parseInt(S.accent.slice(1), 16), l = .299 * (n >> 16) + .587 * (n >> 8 & 255) + .114 * (n & 255);
    r.style.setProperty("--accent", S.accent); r.style.setProperty("--on", l > 150 ? "#111" : "#fff");
  } else { r.style.removeProperty("--accent"); r.style.removeProperty("--on"); }
  try { localStorage.setItem("mt_set", JSON.stringify(S)); } catch (e) {}
}

function modal(title, body, btns, cancel) {
  return new Promise(res => {
    dlg.replaceChildren();
    const a = h("div", "dact"), b = h("div");
    typeof body === "string" ? b.innerHTML = body : b.append(body);
    btns.forEach((t, i) => { const x = h("button", i ? "ghost" : "", t); x.onclick = () => { dlg.close(); res(t); }; a.append(x); });
    dlg.append(h("h2", null, title), b, a);
    dlg.oncancel = e => { if (cancel) res(null); else e.preventDefault(); };
    dlg.showModal();
  });
}

function buildBoard() {
  const B = $("board"); B.querySelectorAll(".c").forEach(e => e.remove()); cells = [];
  game.sp.forEach((s, i) => {
    const [r, c] = i <= 10 ? [11, 11 - i] : i < 20 ? [21 - i, 1] : i <= 30 ? [1, i - 19] : [i - 29, 11];
    const side = i % 10 === 0 ? "" : i < 10 ? "b" : i < 20 ? "l" : i < 30 ? "t" : "r";
    const d = h("div", `c ${side} ${s.type}`); d.style.gridArea = `${r}/${c}`;
    const bar = h("div", "bar"); if (s.g) bar.style.background = G[s.g][0];
    const nm = h("div", "nm"), ic = { railroad: "☁️", utility: "📡", chance: "❓", chest: "📦", tax: "💸", corner: s.ic }[s.type];
    if (ic) nm.append(h("span", "ic", ic));
    nm.append(h("span", null, s.name));
    if (s.price || s.amount) nm.append(h("span", "pr", (s.price || s.amount) + "M"));
    d.append(bar, nm, h("div", "tk")); B.append(d); cells.push(d);
  });
}

function render() {
  if (!game) return;
  game.sp.forEach((s, i) => {
    const d = cells[i], o = s.owner === null ? null : game.players[s.owner];
    d.style.setProperty("--own", o ? o.color : "transparent");
    d.classList.toggle("owned", !!o); d.classList.toggle("mort", s.mort);
    if (s.g) d.firstChild.textContent = s.houses > 4 ? "🏨" : "🏠".repeat(s.houses);
  });
  game.players.forEach((p, i) => {
    const c = pcs[i];
    c.classList.toggle("act", i === game.cur && !game.over); c.classList.toggle("out", p.out);
    c.querySelector(".mn").textContent = p.money + "M";
    c.querySelector(".pp").replaceChildren(...game.own(i).map(s => { const x = h("i", s.mort ? "m" : ""); x.style.background = s.g ? G[s.g][0] : "var(--mut)"; x.title = s.name; return x; }));
    if (p.out) tokens[i].remove();
  });
  const p = game.p();
  $("turn").textContent = game.over ? "Partida terminada" : `Turno de ${p.name}` + (p.inJail ? " · en la Auditoría" : "") + (p.cards ? ` · ${p.cards} carta(s) de salida` : "");
  $("roll").disabled = $("manage").disabled = busy || game.over;
}

function propCard(s) {
  const d = h("div", "pcard"), b = h("div", "pband", s.name);
  b.style.background = s.g ? G[s.g][0] : "var(--panel2)"; d.append(b);
  const rows = s.type === "property"
    ? [["Alquiler", s.r + "M"], ["Con el set completo", s.r * 2 + "M"], ...[1, 2, 3, 4, 5].map(k => [k < 5 ? k + " 🏠" : "🏨", Math.round(s.r * MULT[s.g][k - 1]) + "M"]), ["Coste por casa", G[s.g][1] + "M"]]
    : s.type === "railroad" ? [["1 nube", "25M"], ["2 nubes", "50M"], ["3 nubes", "100M"], ["4 nubes", "200M"]]
    : [["1 servicio", "4× dados"], ["2 servicios", "10× dados"]];
  rows.push(["Hipoteca", s.price / 2 + "M"]);
  rows.forEach(([a, c]) => { const r = h("div", "pr2"); r.append(h("span", null, a), h("b", null, c)); d.append(r); });
  return d;
}

async function manage(g, p) {
  const i = g.idx(p), body = h("div"), top = h("p");
  const draw = () => {
    body.replaceChildren(top); top.textContent = "Fondos: " + p.money + "M";
    const mine = g.own(i); if (!mine.length) body.append(h("p", "mut", "Aún no tienes propiedades."));
    mine.forEach(s => {
      const r = h("div", "mrow"), dot = h("i"); dot.style.background = s.g ? G[s.g][0] : "var(--mut)";
      const btn = (t, ok, fn) => { const b = h("button", "ghost sm", t); b.disabled = !ok; b.onclick = () => { fn(); render(); draw(); }; return b; };
      r.append(dot, h("span", null, s.name + (s.houses ? ` (${s.houses > 4 ? "🏨" : s.houses + "🏠"})` : "") + (s.mort ? " · hipotecada" : "")));
      if (s.type === "property") r.append(btn("+", g.canBuild(s), () => g.build(s)), btn("−", g.canSell(s), () => g.sell(s)));
      r.append(s.mort ? btn(`Pagar ${g.unmortCost(s)}M`, g.canUnmort(s), () => g.unmort(s)) : btn(`Hipotecar +${s.price / 2}M`, g.canMort(s), () => g.mort(s)));
      body.append(r);
    });
  };
  draw(); await modal("Gestionar propiedades", body, ["Cerrar"], true);
}

const hooks = {
  render, manage,
  log: (m, c) => { const d = h("div", c || ""), L = $("log"); d.innerHTML = m; L.append(d); while (L.children.length > 150) L.firstChild.remove(); L.scrollTop = L.scrollHeight; },
  step: async p => { const t = tokens[game.idx(p)]; cells[p.pos].querySelector(".tk").append(t); t.classList.remove("hop"); void t.offsetWidth; t.classList.add("hop"); await wait(140); },
  dice: async (a, b) => {
    const D = [$("d1"), $("d2")], F = "⚀⚁⚂⚃⚄⚅"; D.forEach(d => d.classList.add("roll"));
    if (S.anim) for (let k = 0; k < 6; k++) { D.forEach(d => d.textContent = F[Math.random() * 6 | 0]); await sleep(80); }
    D[0].textContent = F[a - 1]; D[1].textContent = F[b - 1]; D.forEach(d => d.classList.remove("roll")); await wait(250);
  },
  flash: (p, v) => { if (!v) return; const f = h("span", "fl " + (v < 0 ? "neg" : "pos"), (v > 0 ? "+" : "") + v + "M"); pcs[game.idx(p)].append(f); setTimeout(() => f.remove(), 1300); },
  ask: (t, x, b) => modal(t, "<p>" + x + "</p>", b),
  card: (k, t) => modal(k === "chance" ? "Noticias Tech" : "Tendencias Tech", `<p class="cardtxt">${t}</p>`, ["Entendido"]),
  buy: async (s, p) => (await modal(`${p.name}: ¿comprar ${s.name}?`, propCard(s), [`Comprar por ${s.price}M`, "No comprar"]) || "").startsWith("Comprar"),
  win: p => modal(`¡${p.name} gana la partida!`, `<p>Se queda como único inversor con ${p.money}M.</p>`, ["Continuar"])
};

function start(cfg) {
  game = new Game(cfg, hooks); busy = false; $("log").replaceChildren(); buildBoard();
  const P = $("players"); P.replaceChildren(); pcs = []; tokens = [];
  game.players.forEach(p => {
    const c = h("div", "pc"); c.style.setProperty("--pcol", p.color);
    c.append(h("span", "pi", p.icon), h("b", null, p.name), h("span", "mn"), h("div", "pp")); P.append(c); pcs.push(c);
    const t = h("div", "tok", p.icon); t.style.background = p.color; tokens.push(t); cells[0].querySelector(".tk").append(t);
  });
  hooks.log("Bienvenidos. Cada inversor empieza con 1500M."); render();
}

async function setup() {
  let n = 2; const names = ["Inversor 1", "Inversor 2", "Inversor 3", "Inversor 4"], ics = [0, 1, 2, 3];
  const body = h("div"), cnt = h("div", "seg"), list = h("div");
  const draw = () => {
    cnt.replaceChildren(...[2, 3, 4].map(k => { const b = h("button", k === n ? "on" : "ghost", k + " jugadores"); b.onclick = () => { n = k; draw(); }; return b; }));
    list.replaceChildren(...names.slice(0, n).map((nm, i) => {
      const r = h("div", "prow"), s = h("select"), t = h("input"); r.style.setProperty("--pcol", COLORS[i]);
      ICONS.forEach((ic, j) => { const o = h("option", null, ic); o.value = j; s.append(o); }); s.value = ics[i]; s.onchange = () => ics[i] = +s.value;
      t.value = nm; t.maxLength = 14; t.setAttribute("aria-label", "Nombre del jugador " + (i + 1)); t.oninput = () => names[i] = t.value; r.append(s, t); return r;
    }));
  };
  draw(); body.append(cnt, list);
  await modal("Nueva partida", body, ["Empezar"]);
  start(names.slice(0, n).map((nm, i) => ({ name: nm.trim() || "Inversor " + (i + 1), icon: ICONS[ics[i]], color: COLORS[i] })));
}

function settings() {
  const b = h("div"), row = (l, c) => { const r = h("label", "srow"); r.append(h("span", null, l), c); b.append(r); };
  const th = h("div", "seg"); th.style.margin = 0;
  [["silicio", "Silicio"], ["plano", "Plano"], ["neon", "Neón"]].forEach(([k, l]) => {
    const x = h("button", S.theme === k ? "on" : "ghost", l);
    x.onclick = () => { S.theme = k; th.querySelectorAll("button").forEach(y => y.className = "ghost"); x.className = "on"; apply(); }; th.append(x);
  });
  const ac = h("input"); ac.type = "color"; ac.value = S.accent || "#e0a458"; ac.oninput = () => { S.accent = ac.value; apply(); };
  const z = h("input"); z.type = "range"; z.min = 70; z.max = 110; z.value = S.zoom; z.oninput = () => { S.zoom = +z.value; apply(); };
  const f = h("select"); [["sans", "Moderna"], ["mono", "Técnica"], ["serif", "Clásica"]].forEach(([k, l]) => { const o = h("option", null, l); o.value = k; f.append(o); });
  f.value = S.font; f.onchange = () => { S.font = f.value; apply(); };
  const an = h("input"); an.type = "checkbox"; an.checked = S.anim; an.onchange = () => { S.anim = an.checked; apply(); };
  const rs = h("button", "ghost sm", "Restablecer"); rs.onclick = () => { S = { ...DEF }; apply(); dlg.close(); settings(); };
  row("Tema", th); row("Color de acento", ac); row("Tamaño del tablero", z); row("Tipografía", f); row("Animaciones", an); b.append(rs);
  modal("Apariencia", b, ["Cerrar"], true);
}

$("roll").onclick = async () => { if (busy || !game || game.over) return; busy = true; render(); await game.turn(); busy = false; render(); if (game.over) setup(); };
$("manage").onclick = async () => { if (busy) return; busy = true; await manage(game, game.p()); busy = false; render(); };
$("opts").onclick = settings;
document.addEventListener("keydown", e => {
  if (e.code === "Space" && !dlg.open && !/INPUT|SELECT|BUTTON|TEXTAREA/.test(document.activeElement.tagName)) { e.preventDefault(); $("roll").click(); }
});
apply(); setup();
